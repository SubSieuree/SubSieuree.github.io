
<!DOCTYPE html>
<!-- Đơn Vị Thiết Kế WEBSITE | LIÊN HỆ ZALO 0846745505 | Bùi Văn Quyết -->
<html lang="vi">
</head>
<link rel="dns-prefetch" href="//SubQuaRe.Me">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>SubQuaRe.Me | Hệ Thống Dịch Vụ Facebook, Youtube, Tiktok, Instagram</title>
<meta name="copyright" content="Bùi Văn Quyết">
<meta name="robots" content="index, follow">
<meta name="revisit-after" content="1 days">
<meta http-equiv="content-language" content="vi">
<meta property="og:url" content="#">
<meta property="og:type" content="website">
<meta property="og:title" content="Hệ Thống Dịch Vụ Facebook, Youtube, Tiktok, Instagram | SubQuaRe.Me">
<meta property="og:description" content="Hệ Thống Hỗ Trợ Dịch Vụ Mạng Xã Hội Facebook, TikTok, Instagram,... Uy Tín Nhất Hiện Nay.">
<meta property="og:image" content="/assets/img/home-banner.jpg">
<meta property="fb:app_id" content="">
<meta name="twitter:title" content="Hệ Thống Dịch Vụ Facebook, Youtube, Tiktok, Instagram | SubQuaRe.Me">
<meta name="twitter:description" content="Hệ Thống Hỗ Trợ Dịch Vụ Mạng Xã Hội Facebook, TikTok, Instagram,... Uy Tín Nhất Hiện Nay.">
<link rel="shortcut icon" href="/assets/img/favicon/favicon.ico" />
<link rel="shortcut icon" href="/landing/img/core-img/logo.png">
<link rel="stylesheet" href="/landing/css/style.css">
<link rel="stylesheet" href="/landing/css/responsive.css">
<style>.page_speed_584156328{ padding-bottom: 70px } .page_speed_615941279{ background: #edf6fd } .page_speed_2139615001{ background-image: url(/landing/img/core-img/pattern.png) }</style>
</style>
</head>
<body class="light-version">
<div id="preloader">
<div class="preload-content">
<div id="dream-load"></div>
</div>  
</div>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="banner">
<div class="container">
<a class="navbar-brand" href="/"><span><img src="landing/img/core-img/logo.png" alt="logo"></span> SubQuaRe.Me</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link" href="/">Trang Chủ</a>
    </li>
        <li class="nav-item">
            <a class="nav-link" href="https://www.facebook.com/Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All/">Liên Hệ Facebook</a>
    </li>
        <li class="nav-item">
            <a class="nav-link" href="https://zalo.me/0846745505">Liên Hệ Zalo</a>
    </li>
        <li class="lh-55px">
            <a href="/auth/login" class="btn login-btn ml-50">Tham Gia Ngay</a>
    </li>
   </ul>
  </div>
 </div>
</nav>
 <section class="hero-section v2 section-padding" id="home">
    <div class="hero-section-content">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-lg-6 col-md-12">
                    <div class="welcome-content">
                        <div class="promo-section">
                            <div class="integration-link">
                                <div class="integration-icon">
                                    <p class="badge">HOT</p>
                                        </div>
                                            <span class="integration-text">Chào Mừng Bạn Đến Với SubQuaRe.Me</span>
                                        </div>
                                    </div>
                                <h1 class="b-text bold fadeInUp" data-wow-delay="0.2s"> Tạo hiệu ứng cho sự nổi tiếng của bạn </h1>
                            <p class="fadeInUp" data-wow-delay="0.3s">
                        Hệ Thống Chuyên Cung Cấp Các Dịch Vụ Tăng Like, Follow, Share, Comment, View Video,.. Cho Các Dịch Vụ Mạng Xã Hội Như Facebook, TikTok, Instagram, Youtube.
                    </p>
                    <div class="info-btn-group fadeInUp" data-wow-delay="0.4s">
                        <a href="/auth/login" class="btn info-btn mr-3">Đăng Nhập</a>
                        <a href="/auth/register" class="btn info-btn">Đăng Kí</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<div class="clearfix"></div>
    <div class="double-bg-1">
        <section id="pricing" class="pricing section-padding-100-70">
            <div class="container">
                <div class="section-heading text-center">
                    <div data-wow-delay="0.2s" class="sect-icon justify-content-center wow fadeInUp" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                        <img src="landing/img/svg/section-icon-2.svg" alt="">
                    </div>
                    <h2 data-wow-delay="0.3s" class="wow fadeInUp" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;"> Dịch Vụ Nổi Bật </h2>
                    <p data-wow-delay="0.4s" class="wow fadeInUp" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;"></p> Các Nền Tảng Dịch Vụ Được Sử Dụng Nhiều Nhất Của Hệ Thống </p>
            </div>
            <div class="row">
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="service_single_content box-shadow text-center mb-100 wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                        <img src="landing/img/icons/icon-fb.png" alt="" width="55px" class="icon-mxh mb-3">
                        <p>Tăng Like, Follow, Share, Comment, View Video...</p>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="service_single_content box-shadow text-center mb-100 wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                        <img src="/landing/img/icons/icon-ig.png" alt="" width="55px" class="icon-mxh mb-3">
                        <p>Tăng Like, Follow, Share, Comment, View Video...</p>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="service_single_content box-shadow text-center mb-100 wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
                    <img src="/landing/img/icons/icon-tt.png" alt="" width="55px" class="icon-mxh mb-3">
                    <p>Tăng Like, Follow, Share, Comment, View Video...</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<div class="clearfix"></div>
    <section id="pricing" class="pricing section-padding-100-70 page_speed_615941279">
        <div class="container">
            <div class="section-heading text-center">
                <div class="sect-icon justify-content-center fadeInUp" data-wow-delay="0.2s">
                    <img src="/landing/img/svg/section-icon-2.svg" alt="">
                    </div>
                    <h2 data-wow-delay="0.3s" class="wow fadeInUp" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;"> Cấp Bậc Ưu Đãi Khách Hàng </h2>
                    <p data-wow-delay="0.4s" class="wow fadeInUp" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;"></p> Có Từng Cấp Bậc Riêng Dành Cho Thành Viên Cực Hấp Dẫn </p>
            </div>
            <div class="row no-gutters">
<div class="col-lg-4 col-md-6">
<div class="single_price_table_content text-center wow fadeInUp" data-wow-delay="0.2s">
<div class="price_table_text">
<h5>Thường</h5>
<h1>Thành viên</h1>
</div>
<div class="table_text_details">
<p>Cấp bậc này không có ưu đãi.</p>
</div>
<div class="table_btn mt-50">
<a href="/" class="btn info-btn">Xem ngay</a>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="single_price_table_content active text-center wow fadeIn" data-wow-delay="0.3s">
<div class="price_table_text">
<h5>Vip</h5>
<h1>Cộng tác viên</h1>
</div>
<div class="table_text_details">
<p>Cấp bậc này có có ưu đãi.</p>
</div>
<div class="table_btn mt-50">
<a href="/" class="btn info-btn">Xem ngay</a>
</div>
</div>
</div>
<div class="col-lg-4 col-md-6">
<div class="single_price_table_content text-center wow fadeInUp" data-wow-delay="0.4s">
<div class="price_table_text">
<h5>Cực Vip</h5>
<h1>Đại lý</h1>
</div>
<div class="table_text_details">
<p>Cấp bậc này có có ưu đãi.</p>
</div>
<div class="table_btn mt-50">
<a href="/" class="btn info-btn">Xem ngay</a>
        </section>
        <footer class="footer-area bg-img">
            <div class="footer-content-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <div class="footer-copywrite-info">
                                <div class="copywrite_text fadeInUp" data-wow-delay="0.2s">
                                    <div class="footer-logo">
                                        <a href="#">
                                            <img src="/landing/img/core-img/logo.png" alt="logo"> SubQuaRe.Me
                                        </a>
                                    </div>
                                    <p> Copyright 2021 <strong>SubQuaRe.Me</strong> - Hệ thống được thiết kế và vận hành bởi <strong>Bùi Văn Quyết</strong>.</p>
                                </div>
                                <div class="footer-social-info fadeInUp" data-wow-delay="0.4s">
                                    <a href="https://www.facebook.com/Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All/">
                                        <i class="fa fa-facebook" aria-hidden="true">
                                        </i>
                                    </a>
                                    <a href="#">
                                        <i class="fa fa-twitter" aria-hidden="true">
                                        </i>
                                    </a>
                                    <a href="#">
                                        <i class="fa fa-google-plus" aria-hidden="true">
                                        </i>
                                    </a>
                                    <a href="#">
                                        <i class="fa fa-instagram" aria-hidden="true">
                                        </i>
                                    <a href="https://www.youtube.com/channel/UCCPrYZ9FvyBK7Q2opogozzw">
                                        <i class="fa fa-youtube" aria-hidden="true">
                                        </i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <script src="/landing/js/jquery.min.js" type="text/javascript"></script>
        <script src="/landing/js/popper.min.js" type="text/javascript"></script>
        <script src="/landing/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="/landing/js/plugins.js" type="text/javascript"></script>
        <script src="/landing/js/script.js" type="text/javascript"></script>
        </script>
    </body>
</html>
<!-- Đơn Vị Thiết Kế WEBSITE | LIÊN HỆ ZALO 0846745505 | Bùi Văn Quyết -->
 