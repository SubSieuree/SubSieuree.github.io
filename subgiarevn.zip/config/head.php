<?php require('function.php'); ?>
<!doctype html><html lang="vi">
<head>
<link rel="dns-prefetch" href="//<?=$_SERVER['SERVER_NAME']?>">
<!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
<link rel="dns-prefetch" href="//www.googletagmanager.com"
><link rel="dns-prefetch" href="//ui-avatars.com">
<link rel="dns-prefetch" href="//zalo.me">
<link rel="dns-prefetch" href="//www.w3.org">
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Hệ Thống Dịch Vụ Mạng Xã Hội Facebook | TikTok | Instagram | SubQuaRe.Me</title>
<meta name="robots" content="index, follow" />
<!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
<meta name="revisit-after" content="1 days" />
<meta http-equiv="content-language" content="vi" />
<meta name="copyright" content="Bùi Văn Quyết" />
<meta name="author" content="Bùi Văn Quyết" />
<meta name="momo" content="0846745505" />
<meta name="zalo" content="0846745505" />
<meta name="robots" content="index, follow" />
<meta name="revisit-after" content="1 days" />
<meta http-equiv="content-language" content="vi" />
<meta property="og:url" content="https://<?=$_SERVER['SERVER_NAME']?>" />
<meta property="og:type" content="website" />
<meta property="og:domain" content="<?=$_SERVER['SERVER_NAME']?>" />
<meta property="og:title" content="Hệ thống dịch vụ mạng xã hội Facebook | Instagram | Youtube | Tiktok | <?=$NHQ->site('ten_website');?>" />
<meta property="og:description" content="Hệ thống dịch vụ mạng xã hội Facebook | Instagram | Youtube | Tiktok | <?=$NHQ->site('ten_website');?>" />
<meta property="og:image" content="<?=BASE_URL('assets/img/home-banner.jpg');?>" />
<meta property="fb:app_id" content="" />
<!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
<meta name="twitter:title" content="Hệ thống dịch vụ mạng xã hội Facebook | Instagram | Youtube | Tiktok | <?=$NHQ->site('ten_website');?>">
<meta name="twitter:description" content="Hệ thống dịch vụ mạng xã hội Facebook | Instagram | Youtube | Tiktok | <?=$NHQ->site('ten_website');?>">
<meta name="csrf-token" content="9jILCFLdUiKHj5NIvPwKO98dWO5obzeL3msiDKcQ">
<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/font-awesome-line-awesome/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/remixicon@2.2.0/fonts/remixicon.css" rel="stylesheet">
<!--<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">-->
<link rel="shortcut icon" href="<?=BASE_URL('assets/img/favicon/favicon.ico');?>" />
<link rel="stylesheet" href="<?=BASE_URL('assets/css/backend.min.css');?>">
<link rel="stylesheet" href="<?=BASE_URL('assets/css/app.css?1627906560');?>">
<link rel="stylesheet" href="<?=BASE_URL('assets/1.3.0/css/line-awesome.css');?>">
<link rel="stylesheet" href="<?=BASE_URL('assets/1.3.0/css/line-awesome.min.css');?>">
<style>.page_speed_1914807038 {margin: 0;}.page_speed_954296520 {background: url(<?=BASE_URL('assets/img/background/background.png');?>)
no-repeat scroll right center;background-color: #ffffff;background-size: contain;}.page_speed_1542575737 {cursor: pointer;}.page_speed_68537186 {width: 85px;height: 85px;}.page_speed_1346386511 {padding: 10px;
    border-radius: 20px;} </style>
<style>
    .alert, .card, .info-box{
        box-shadow: 1px 1px 25px rgb(0 0 0 / 15%);
    }
    .info-box {
            border-radius: .25rem;
            background-color: #fff;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            margin-bottom: 1rem;
            min-height: 80px;
            padding: .5rem;
            position: relative;
            width: 100%;
        }

        .info-box .info-box-icon {
            border-radius: .25rem;
            -webkit-align-items: center;
            -ms-flex-align: center;
            align-items: center;
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            font-size: 1.875rem;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            text-align: center;
            width: 70px;
        }

        .info-box .info-box-content {
            display: -webkit-flex;
            display: -ms-flexbox;
            display: flex;
            -webkit-flex-direction: column;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-justify-content: center;
            -ms-flex-pack: center;
            justify-content: center;
            line-height: 1.8;
            -webkit-flex: 1;
            -ms-flex: 1;
            flex: 1;
            padding: 0 10px;
        }

        .info-box .info-box-text,
        .info-box .progress-description {
            display: block;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .info-box .info-box-number {
            display: block;
            margin-top: .25rem;
            font-weight: 700;
        }
</style>
</head>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-EVLQMPJW25" type="b9e3e84309a92aaf852234bf-text/javascript"></script>
<script src="https://js.hcaptcha.com/1/api.js" async defer></script><script src="https://www.google.com/recaptcha/api.js"></script>
<script type="b9e3e84309a92aaf852234bf-text/javascript">
window.dataLayer = window.dataLayer || [];function gtag() {dataLayer.push(arguments);}gtag('js', new Date());gtag('config', 'G-EVLQMPJW25');</script>
<style>.checkbox:checked+img {border: 3px solid #e63946;position: relative;top: -10px;transform: scale(1.2);}</style>
<style>body {margin: 0;font-family: var(--bs-body-font-family);font-size: var(--bs-body-font-size);font-weight: 
var(--bs-body-font-weight);line-height: var(--bs-body-line-height);color: var(--bs-body-color);text-align: var(--bs-body-text-align);background-color:
var(--bs-body-bg);-webkit-text-size-adjust: 100%;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);}</style>
