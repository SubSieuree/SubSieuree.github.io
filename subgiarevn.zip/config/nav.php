<div class="iq-sidebar sidebar-default ">
            <div class="iq-sidebar-logo d-flex align-items-center justify-content-between">
                <a href="<?=BASE_URL('home');?>" class="header-logo" style="text-transform: uppercase; font-size:30px;">
                <img src="<?=BASE_URL('')?>assets/img/logo/logo.png" class="img-fluid rounded-normal light-logo" alt="logo">
                <img src="<?=BASE_URL('')?>assets/img/logo/logo.png" class="img-fluid rounded-normal darkmode-logo" alt="logo">
                </a>
                <div class="iq-menu-bt-sidebar"><i class="las la-bars wrapper-menu"></i>
                </div>
            </div>
            <!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
            <div class="data-scrollbar" data-scroll="1">
                <nav class="iq-sidebar-menu">
                    <ul id="iq-sidebar-toggle" class="iq-menu">
                        <li class="active"><a href="<?=BASE_URL('home');?>" class=""><span class="icon-menu"><img src="/assets/images/icon/home.svg" alt=""></span>
                        <span class="text-menu">Trang Chủ</span>
                        </a>
                        </li>
                        <li class=""><a href="<?=BASE_URL('profile/info');?>" class=""><span class="icon-menu"><img src="/assets/images/icon/profile.svg" alt=""></span>
                        <span class="text-menu">Tài Khoản Của Tôi</span>
                        </a>
                        </li>
                        <li class=""><a href="<?=BASE_URL('recharge/banking');?>" class=""><span class="icon-menu"><img src="/assets/images/icon/bank.svg" alt=""></span>
                        <span class="text-menu">Nạp Tiền Tài Khoản</span>
                        </a>
                        </li>
                        <li class=""><a href="<?=BASE_URL('profile/upgrade-level');?>" class=""><span class="icon-menu"><img src="/assets/images/icon/vip.svg" alt=""></span>
                        <span class="text-menu">Nâng Cấp Bậc</span>
                        </a>
                        </li>
                        <li class=""><a href="<?=BASE_URL('website/create')?>" class=""><span class="icon-menu"><img src="/assets/images/icon/globe.svg" alt=""></span>
                        <span class="text-menu">Tạo Website Riêng</span></a>
                        </li>
                        <li class=""><a href="<?=BASE_URL('profile/statistical');?>" class=""><span class="icon-menu"><img src="/assets/images/icon/pie-chart.svg" alt=""></span>
                        <span class="text-menu">Thống Kê Dòng Tiền</span>
                        </a>
                        </li>
                        <li class=""><a href="<?=BASE_URL('service/view/buy');?>" class=""><span class="icon-menu"><img src="/assets/images/icon/tag.svg" alt=""></span>
                        <span class="text-menu">Dịch Vụ Miễn Phí</span>
                        </a>
                        </li>
                        <!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
                        <li class=" "><a href="#serviceFacebook" class="collapsed" data-toggle="collapse" aria-expanded="false">
                            <span class="icon-menu"><img src="/assets/images/icon/facebook.svg" alt=""></span>
                        <span class="text-menu">Dịch Vụ Facebook</span>
                        <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                        <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                        </a>
                            <ul id="serviceFacebook" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                <li class="">
                                    <a href="<?=BASE_URL('service/like-post-sale/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/like-1.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like Bài Viết (Sale)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/like-tay/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/like-3.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like Bài Viết (Tây)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/like-post-speed/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/like-2.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like Bài Viết (speed)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/comment-sale/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/comment-1.svg" alt=""></span>
                                    <span class="text-menu">Tăng Bình Luận (sale)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/sub-sale/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/follow-1.svg" alt=""></span>
                                    <span class="text-menu">Tăng Sub/Follow (Sale)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/sub-speed/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/follow-2.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like/Follow (Speed)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/like-page-sale/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/like-page-1.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like/Follow Page (Sale)</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/eyelive/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/eye-live.svg" alt=""></span>
                                    <span class="text-menu">Tăng Mắt Live</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('/');?>"><span class="icon-menu"><img src="/assets/images/icon/share.svg" alt=""></span>
                                    <span class="text-menu">Tăng Share Profile</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('/');?>"><span class="icon-menu"><img src="/assets/images/icon/youth.svg" alt=""></span>
                                    <span class="text-menu">Tăng Member Group</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/eyevideo/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/view-video.svg" alt=""></span>
                                    <span class="text-menu">Tăng View Video</span></a>
                                    </a>
                                </li>
                                </ul>
                                </li>
                                <li class=" "><a href="#serviceInstagram" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                    <span class="icon-menu"><img src="/assets/images/icon/instagram.svg" alt=""></span>
                                        <span class="text-menu">Dịch Vụ Instagram (bảo trì)</span>
                                    <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                    <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                </a>
                                <ul id="serviceInstagram" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                <li class="">
                                    <a href="<?=BASE_URL('service/instagram/like-post/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/like-3.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like Bài Viết</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/instagram-sub_sale_ing/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/follow-1.svg" alt=""></span>
                                    <span class="text-menu">Tăng Sub/Follow</span></a>
                                </li>
                                </ul>
                                </li>
                                <li class=" "><a href="#serviceTiktok" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                    <span class="icon-menu"><img src="/assets/images/icon/tiktok.svg" alt=""></span>
                                        <span class="text-menu">Dịch Vụ TikTok (bảo trì)</span>
                                    <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                    <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                </a>
                                <ul id="serviceTiktok" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                <li class="">
                                    <a href="<?=BASE_URL('service/like-post-sale/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/like-3.svg" alt=""></span>
                                    <span class="text-menu">Tăng Like Bài Viết</span></a>
                                </li>
                                <li class="">
                                    <a href="<?=BASE_URL('service/like-post-speed/buy');?>"><span class="icon-menu"><img src="/assets/images/icon/follow-1.svg" alt=""></span>
                                    <span class="text-menu">Tăng Sub/Follow</span></a>
                                </li>
                                </ul>
                                </li>
                                <li class=" ">
                                    <a href=" #support" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                        <span class="icon-menu"><img src="/assets/images/icon/communicate.svg" alt=""></span>
                                        <span class="text-menu">Liên Hệ & Hỗ Trợ</span>
                                    <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                            </a>
                            <ul id="support" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                <li class="">   
                                    <a href=" https://www.facebook.com/Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All/" target="_blank" rel="noopener noreferrer">
                                        <span class="icon-menu"><img src="/assets/images/icon/facebook.svg" alt=""></span>
                                        <span class="text-menu">Facebook</span>
                                        </a>
                                    </li>
                                <li class="">   
                                    <a href=" https://zalo.me/0846745505" target="_blank" rel="noopener noreferrer">
                                        <span class="icon-menu"><img src="/assets/images/icon/chat.svg" alt=""></span>
                                        <span class="text-menu">Zalo</span>
                                        </a>
                                    </li>
                                <li class="">   
                                    <a href=" https://t.me/quyetcoder2k3" target="_blank" rel="noopener noreferrer">
                                        <span class="icon-menu"><img src="/assets/images/icon/telegram.svg" alt=""></span>
                                        <span class="text-menu">Telegram</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php if($NHQ->getUsers('level') == 'admin' && $NHQ->getUsers('capbac') == 3){?>
                        <!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
                        <li class=" "><a href="#websiteApi" class="collapsed" data-toggle="collapse" aria-expanded="false"><span class="icon-menu"><img src="/assets/images/icon/cp-admin.svg" alt=""></span>
                        <span class="text-menu">Trang Quản Trị</span><i class="las la-angle-right iq-arrow-right arrow-active"></i>
                        <i class="las la-angle-down iq-arrow-right arrow-hover"></i></a>
                            <ul id="websiteApi" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                <li class=" "><a href="<?=BASE_URL('admin/user/list');?>"><span class="icon-menu"><img src="/assets/images/icon/profile.svg" alt=""></span>
                                <span class="text-menu">Quản Lí Thành Viên</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/recharge/quanly');?>"><span class="icon-menu"><img src="/assets/images/icon/bank.svg" alt=""></span>
                                <span class="text-menu">Quản Lý Nạp Tiền</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/order/list');?>"><i class="las la-clipboard-list"></i>
                                <span class="text-menu">Quản Lý Đơn Hàng</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/thongbao/add');?>"><span class="icon-menu"><img src="/assets/images/icon/notification.svg" alt=""></span>
                                <span class="text-menu">Thêm Thông Báo</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/thongbao/home/add');?>"><i class="las la-eye"></i>
                                <span class="text-menu">Thông Báo Nổi</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/info/admin/edit');?>"><i class="las la-ad"></i>
                                <span class="text-menu">Thông Tin ADMIN</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/recharge/banking/add');?>"><i class="las la-hand-holding-usd"></i>
                                <span class="text-menu">Cài Đặt Ngân Hàng</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/recharge/card/edit');?>"><i class="las la-donate"></i>
                                <span class="text-menu">Cài Đặt Nạp Thẻ</span></a>
                                </li>
                                <li class=" "><a href="<?=BASE_URL('admin/setting/website/edit');?>"><i class="las la-tools"></i>
                                <span class="text-menu">Cài Đặt Website</span></a>
                                </li>
                            </ul>
                        </li>
                        <!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
                        <li class=" "><a href="#serviceApi" class="collapsed" data-toggle="collapse" aria-expanded="false"><span class="icon-menu"><img src="/assets/images/icon/pie-chart.svg" alt=""></span>
                        <span class="text-menu">Quản Lý Dịch Vụ</span><i class="las la-angle-right iq-arrow-right arrow-active"></i>
                        <i class="las la-angle-down iq-arrow-right arrow-hover"></i></a>
                            <ul id="serviceApi" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                <li class=" "><a href="<?=BASE_URL('admin/service/quanly/facebook');?>"><span class="icon-menu"><img src="/assets/images/icon/facebook.svg" alt=""></span>
                                <span class="text-menu">Dịch vụ facebook</span></a></li>
                                <li class=" "><a href="<?=BASE_URL('admin/service/quanly/free');?>"><span class="icon-menu"><img src="/assets/images/icon/tag.svg" alt=""></span>
                                <span class="text-menu">Dịch vụ free</span></a></li>
                        </li>
                        <?php }?>
                    </ul>
                <!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
                <div class="p-3"></div>
            </div>
        </div>
<!-- Design by Bùi Văn Quyết /Facebook: Bui.Van.Quyet.Vo.Dich.Thien.Ha.Can.All//zalo: 0846745505/3.x [XR&CO'2021], Tue, 2 Aug 2021 11:19:24 GMT -->
