<?php require_once '../config//function.php';

$APIKey = "ALI9QJOTBY83X0189Z2P";
$phone = "0846745505";

$object = json_decode(file_get_contents("php://input"));
 
if (!empty($object)) {
    $signature = hash("sha256", $phone.$APIKey);
    
    if ($signature == $object->signature) {
    	$transactionId = $object->transactionId; #mã giao dịch momo
        $amount = $object->amount;               #số tiền bạn nhận được
        $sender = $object->sender;               #tên người gửi
        $senderId = $object->senderId;           #Id người gửi
        $content = $object->content;             #nội dung
        
        if (strpos($content, " SubQuaRe") !== false) {
            $id = explode("_", $content)[1];
            
            $name = $ketnoi->query("SELECT * FROM `users` WHERE `id` = {$id}")->fetch_array()['username'];
            
            $ketnoi->query("INSERT INTO `momo` SET
                                `tranId`      = '{$transactionId}',
                                `username`    = '{$name}',
                                `comment`     = '{$content}',
                                `time`        = '{$time}',
                                `partnerId`   = '{$senderId}',
                                `amount`      = '{$amount}',
                                `partnerName` = '{$sender}'");
                                
            $cash = format_cash($amount);
                                
            $ketnoi->query("INSERT INTO `log` SET 
                `content` = '+ {$cash} Lý do: Nạp MOMO Auto  #{$transactionId}',
                `createdate` = now(),
                `username`   = '{$name}'");
                
            $ketnoi->query("UPDATE users SET 
                `money` = `money` + {$amount},
                `total_nap` = `total_nap` + {$amount} WHERE `username` = '{$name}'");
                
            $return['msg'] = "Nạp tiền thành công!";
            $return['type'] = "success";
        }
    } else {
        $return['msg'] = "Sai chữ ký";
        $return['type'] = "error";
    }
} else {
    $return['msg'] = "Thiếu thông tin gửi lên";
    $return['type'] = "error";
}

echo json_encode($return);