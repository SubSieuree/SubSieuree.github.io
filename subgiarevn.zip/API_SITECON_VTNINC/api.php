<?php
require('../SITECON_VTNINC/sitecon.php');

$return['status'] = true;
$return['message'] = 'VTNINC';
die(json_encode($return));