<?php
require('../config/function.php');

$return['status'] = true;
$return['message'] = 'OK';
die(json_encode($return));